/* content.js — appelle l'API TikTok directement, sans scroller la page */

(function () {
  if (window.__tiktokScraper) return;

  const state = {
    urls: [],
    seen: new Set(),
    running: false,
    scrollCount: 0, // utilisé comme compteur de pages pour le popup
  };

  function getSecUid() {
    // Extraire le secUid depuis le HTML de la page profil
    const scripts = document.querySelectorAll("script");
    for (const s of scripts) {
      const text = s.textContent;
      if (text.includes("secUid")) {
        const match = text.match(/"secUid"\s*:\s*"([^"]+)"/);
        if (match) return match.group ? match.group(1) : match[1];
      }
    }
    // Fallback : chercher dans le JSON embarqué
    const all = document.documentElement.innerHTML;
    const m = all.match(/"secUid"\s*:\s*"([^"]+)"/);
    return m ? m[1] : null;
  }

  async function fetchAllLikes() {
    state.running = true;
    state.scrollCount = 0;

    const secUid = getSecUid();
    if (!secUid) {
      console.error("[TikTok Scraper] secUid introuvable. Es-tu sur une page profil TikTok ?");
      state.running = false;
      return;
    }

    let cursor = 0;
    let hasMore = true;

    while (hasMore && state.running) {
      try {
        const params = new URLSearchParams({
          secUid: secUid,
          count: "30",
          cursor: String(cursor),
          aid: "1988",
          app_language: "fr",
          app_name: "tiktok_web",
          device_platform: "web_pc",
          channel: "tiktok_web",
          cookie_enabled: "true",
          browser_online: "true",
          screen_width: "1920",
          screen_height: "1080",
        });

        const resp = await fetch(
          `https://www.tiktok.com/api/favorite/item_list/?${params.toString()}`,
          { credentials: "include" }
        );

        if (!resp.ok) {
          console.warn(`[TikTok Scraper] HTTP ${resp.status}`);
          // Petite pause puis retry
          await new Promise((r) => setTimeout(r, 2000));
          continue;
        }

        const data = await resp.json();
        const items = data.itemList || [];

        for (const item of items) {
          const vid = item.id;
          const author = item.author?.uniqueId;
          if (vid && author) {
            const url = `https://www.tiktok.com/@${author}/video/${vid}`;
            if (!state.seen.has(url)) {
              state.seen.add(url);
              state.urls.push(url);
            }
          }
        }

        state.scrollCount++;
        hasMore = !!data.hasMore;
        cursor = data.cursor || 0;

        // Micro-pause entre les requêtes
        await new Promise((r) => setTimeout(r, 300));

      } catch (err) {
        console.warn("[TikTok Scraper] Erreur :", err);
        await new Promise((r) => setTimeout(r, 2000));
      }
    }

    state.running = false;
  }

  window.__tiktokScraper = {
    start() {
      state.urls = [];
      state.seen = new Set();
      state.scrollCount = 0;
      fetchAllLikes();
    },
    stop() {
      state.running = false;
    },
    getState() {
      return {
        urls: [...state.urls],
        running: state.running,
        scrollCount: state.scrollCount,
      };
    },
  };
})();
