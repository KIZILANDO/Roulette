/* popup.js — contrôle le scraping via le content script injecté */

const btnStart = document.getElementById("btnStart");
const btnStop = document.getElementById("btnStop");
const btnExport = document.getElementById("btnExport");
const statusEl = document.getElementById("status");
const countEl = document.getElementById("count");

let collectedUrls = [];
let pollTimer = null;

function setStatus(msg) {
  statusEl.textContent = msg;
}

async function getTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

async function injectAndRun(tab) {
  // Injecter le content script
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: ["content.js"],
  });

  // Lancer le scraping
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => window.__tiktokScraper?.start(),
  });
}

async function pollResults(tab) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => window.__tiktokScraper?.getState(),
    });

    const state = results?.[0]?.result;
    if (!state) return;

    collectedUrls = state.urls;
    countEl.textContent = `${state.urls.length} vidéos`;

    if (state.running) {
      setStatus(`Requête API page ${state.scrollCount}...`);
    } else {
      setStatus("Terminé !");
      clearInterval(pollTimer);
      btnStop.style.display = "none";
      btnStart.style.display = "block";
      if (state.urls.length > 0) {
        btnExport.style.display = "block";
      }
    }
  } catch {
    // tab closed or navigated away
    clearInterval(pollTimer);
    setStatus("Onglet fermé ou changé.");
  }
}

btnStart.addEventListener("click", async () => {
  const tab = await getTab();
  if (!tab?.url?.includes("tiktok.com")) {
    setStatus("⚠ Ouvre d'abord une page TikTok !");
    return;
  }

  btnStart.style.display = "none";
  btnStop.style.display = "block";
  btnExport.style.display = "none";
  collectedUrls = [];
  setStatus("Injection...");

  try {
    await injectAndRun(tab);
    setStatus("Scraping lancé...");
    pollTimer = setInterval(() => pollResults(tab), 1000);
  } catch (err) {
    setStatus("Erreur : " + err.message);
    btnStart.style.display = "block";
    btnStop.style.display = "none";
  }
});

btnStop.addEventListener("click", async () => {
  const tab = await getTab();
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => window.__tiktokScraper?.stop(),
    });
  } catch { /* ignore */ }
  clearInterval(pollTimer);
  btnStop.style.display = "none";
  btnStart.style.display = "block";
  if (collectedUrls.length > 0) {
    btnExport.style.display = "block";
  }
  setStatus("Arrêté.");
});

btnExport.addEventListener("click", () => {
  if (collectedUrls.length === 0) return;

  const text = collectedUrls.join("\n");
  const blob = new Blob([text], { type: "text/plain" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `tiktok_likes_${collectedUrls.length}.txt`;
  a.click();
  URL.revokeObjectURL(url);
  setStatus(`Exporté : ${collectedUrls.length} URLs`);
});
